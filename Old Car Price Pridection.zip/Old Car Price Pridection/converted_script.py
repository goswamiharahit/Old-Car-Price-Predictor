import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import LabelEncoder

dataset = pd.read_csv("cardekho_data.csv")

dataset.head(2)

dataset.isnull().sum()

dataset.info()

Car_Name_le = LabelEncoder()
dataset["Car_Name"] = Car_Name_le.fit_transform(dataset["Car_Name"])

dataset["Fuel_Type"].unique()

Fuel_Type_le = LabelEncoder()
dataset["Fuel_Type"] = Fuel_Type_le.fit_transform(dataset["Fuel_Type"])



Seller_Type_le = LabelEncoder()
dataset["Seller_Type"] = Seller_Type_le.fit_transform(dataset["Seller_Type"])

Transmission_le = LabelEncoder()
dataset["Transmission"] = Transmission_le.fit_transform(dataset["Transmission"])

dataset.head()

# sns.heatmap(data=dataset.corr(),annot=True) #check for linear regresion
# plt.show()

input_data = dataset.iloc[:,:-1] #scaling input data
output_data = dataset["Selling_Price"]

from sklearn.preprocessing import StandardScaler

ss = StandardScaler()
input_data = pd.DataFrame(ss.fit_transform(input_data),columns=input_data.columns)

from sklearn.model_selection import train_test_split

x_train , x_test , y_train , y_test = train_test_split(input_data,output_data,test_size=0.2,random_state=42)

from sklearn.linear_model import LinearRegression , Lasso , Ridge , ElasticNet
from sklearn.tree import DecisionTreeRegressor
from sklearn.svm import SVR
from sklearn.neighbors import KNeighborsRegressor
from sklearn.ensemble import RandomForestRegressor

from sklearn.metrics import mean_squared_error , mean_absolute_error

# lr = LinearRegression()
# lr.fit(x_train,y_train)
# lr.score(x_train,y_train)*100 , lr.score(x_test,y_test)*100

# lr1 = Lasso(alpha=0.05)
# lr1.fit(x_train,y_train)
# lr1.score(x_train,y_train)*100 , lr1.score(x_test,y_test)*100

# lr2 = Ridge(alpha=5)
# lr2.fit(x_train,y_train)
# lr2.score(x_train,y_train)*100 , lr2.score(x_test,y_test)*100

# lr3 = Ridge(alpha=5)
# lr3.fit(x_train,y_train)
# lr3.score(x_train,y_train)*100 , lr3.score(x_test,y_test)*100 

dt = DecisionTreeRegressor(max_depth=16)
dt.fit(x_train,y_train)
dt.score(x_train,y_train)*100 , dt.score(x_test,y_test)*100

mean_squared_error(y_test,dt.predict(x_test)) 
mean_absolute_error(y_test,dt.predict(x_test))

rf = RandomForestRegressor(n_estimators=100)
rf.fit(x_train,y_train)
rf.score(x_train,y_train)*100 , rf.score(x_test,y_test)*100

mean_squared_error(y_test,rf.predict(x_test)) , mean_absolute_error(y_test,rf.predict(x_test))

# sv = SVR()
# sv.fit(x_train,y_train)
# sv.score(x_train,y_train)*100 , sv.score(x_test,y_test)*100

# knn = KNeighborsRegressor(n_neighbors=10)
# knn.fit(x_train,y_train)
# knn.score(x_train,y_train)*100 , knn.score(x_test,y_test)*100

# mean_squared_error(y_test,knn.predict(x_test)) , mean_absolute_error(y_test,knn.predict(x_test))

rf.predict([[-1.275759,0.821718,-0.817924,-0.333500,0.500183,1.356327,-2.554408,-0.17450]])


x_test

y_test

new_data=pd.DataFrame([["i20",2015,6.75,45000,"Petrol","Dealer","Manual",0]],columns=x_train.columns)
				


new_data

# rf.predict(new_data)

new_data["Car_Name"]=Car_Name_le.transform(new_data["Car_Name"])

new_data["Fuel_Type"]=Fuel_Type_le.transform(new_data["Fuel_Type"])

new_data["Seller_Type"]=Seller_Type_le.transform(new_data["Seller_Type"])

new_data["Transmission"]=Transmission_le.transform(new_data["Transmission"])

new_data = pd.DataFrame(ss.transform(new_data),columns=new_data.columns)

new_data

rf.predict(new_data)